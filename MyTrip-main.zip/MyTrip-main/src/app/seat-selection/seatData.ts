export const seatData = [
    {
        id:"A1",
        cost: "1000"
    },
    {
        id:"A2",
        cost: "2000"
    },
    {
        id:"A3",
        cost: "1000"
    },
    {
        id:"A4",
        cost: "2000"
    },
    {
        id:"B1",
        cost: "1000"
    },
    {
        id:"B2",
        cost: "2000"
    },
    {
        id:"B3",
        cost: "1000"
    },
    {
        id:"B4",
        cost: "2000"
    },
    {
        id:"C1",
        cost: "1000"
    },
    {
        id:"C2",
        cost: "2000"
    },
    {
        id:"C3",
        cost: "1000"
    },
    {
        id:"C4",
        cost: "2000"
    },
    {
        id:"D1",
        cost: "1000"
    },
    {
        id:"D2",
        cost: "2000"
    },
    {
        id:"D3",
        cost: "1000"
    },
    {
        id:"D4",
        cost: "2000"
    },
    {
        id:"E1",
        cost: "1000"
    },
    {
        id:"E2",
        cost: "2000"
    },
    {
        id:"E3",
        cost: "1000"
    },
    {
        id:"E4",
        cost: "2000"
    },
    {
        id:"F1",
        cost: "1000"
    },
    {
        id:"F2",
        cost: "2000"
    },
    {
        id:"F3",
        cost: "1000"
    },
    {
        id:"F4",
        cost: "2000"
    },
    {
        id:"G1",
        cost: "1000"
    },
    {
        id:"G2",
        cost: "2000"
    },
    {
        id:"G3",
        cost: "1000"
    },
    {
        id:"G4",
        cost: "2000"
    },
    {
        id:"H1",
        cost: "1000"
    },
    {
        id:"H2",
        cost: "2000"
    },
    {
        id:"H3",
        cost: "1000"
    },
    {
        id:"H4",
        cost: "2000"
    },
    {
        id:"I1",
        cost: "1000"
    },
    {
        id:"I2",
        cost: "2000"
    },
    {
        id:"I3",
        cost: "1000"
    },
    {
        id:"I4",
        cost: "2000"
    },
    {
        id:"J1",
        cost: "1000"
    },
    {
        id:"J2",
        cost: "2000"
    },
    {
        id:"J3",
        cost: "1000"
    },
    {
        id:"J4",
        cost: "2000"
    },
    
]
export interface User{
    userName : string;
    mobile: string;
    email: string;
}
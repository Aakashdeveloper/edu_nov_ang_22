export interface Journey{
    from : string;
    to: string;
    date?: any;
}